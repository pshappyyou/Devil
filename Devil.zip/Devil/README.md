# AngelJS

## Purpose:
Tableau Technical Support Desk Job Queue Dashboard & Management

## Technology Used:
* nodejs
* npm
* expressjs
* esj
* socketio - on. emit
* rethinkdb (nosql)
* python
* sfdx-cli
* docker
